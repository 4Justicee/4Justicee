#define forever while(1)

typedef struct {
    int  type;
    char *value;
    int length;
} REQUEST;

typedef struct {
    char *header;
    char *filename, *filepath;
    int  error;
} RESPONSE;

#define REQUEST_SIZE 4096
#define DEFAULT_PORT 80

#undef DELETE


extern const char *DEFAULT_ERROR_404;

char *get_header(RESPONSE *);
void error_live(const char *);
void error_die(const char *);

int SendResponse(SOCKET sock, RESPONSE *response);
int SendResponse(SOCKET sock, char *response);
BOOL FileExists(LPCTSTR szPath);
char *get_content_type(char *name);
char *get_full_path(char *name);
RESPONSE *GetResponse(REQUEST *request);
REQUEST *GetRequest(SOCKET sock);
char *get_request_value(char *buf);
int get_request_type(char *buf);