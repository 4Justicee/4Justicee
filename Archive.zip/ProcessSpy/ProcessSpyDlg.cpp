// ProcessSpyDlg.cpp : implementation file
//

#include "stdafx.h"
#include "ProcessSpy.h"
#include "ProcessSpyDlg.h"

#include <tlhelp32.h>
#include <winsock2.h>
#include "server.h"

#pragma comment (lib, "Ws2_32.lib")


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#define DEFAULT_BUFLEN 512

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About
CString strpid;
// CAboutDlg dialog used for App About


vector<process_inform>	g_pids;
#define nullptr NULL

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CProcessSpyDlg dialog

CProcessSpyDlg::CProcessSpyDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CProcessSpyDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CProcessSpyDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CProcessSpyDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CProcessSpyDlg)
	DDX_Control(pDX, IDC_LIST1, m_prslist);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CProcessSpyDlg, CDialog)
	//{{AFX_MSG_MAP(CProcessSpyDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BTN_GET, OnBtnGet)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


BOOL CProcessSpyDlg::GetProcessList()
{
	HANDLE hProcessSnap;
	HANDLE hProcess;
	PROCESSENTRY32 pe32;
	DWORD dwPriorityClass;

	// Take a snapshot of all processes in the system.
	hProcessSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
	if (hProcessSnap == INVALID_HANDLE_VALUE)
	{
		return(FALSE);
	}

	// Set the size of the structure before using it.
	pe32.dwSize = sizeof(PROCESSENTRY32);

	// Retrieve information about the first process,
	// and exit if unsuccessful
	if (!Process32First(hProcessSnap, &pe32))
	{
		CloseHandle(hProcessSnap);          // clean the snapshot object
		return(FALSE);
	}

	// Now walk the snapshot of processes, and
	// display information about each process in turn
	static int cnt = 0;
	do
	{
		// Retrieve the priority class.
		dwPriorityClass = 0;
		hProcess = OpenProcess(PROCESS_ALL_ACCESS, FALSE, pe32.th32ProcessID);
		if (hProcess == NULL)
			printf("OpenProcess Error");
		else
		{
			if (hasHwnd(pe32.th32ProcessID)) {
				process_inform inf;
				inf.pid = pe32.th32ProcessID;
				strcpy(inf.processname, pe32.szExeFile);
				g_pids.push_back(inf);
				CloseHandle(hProcess);

				CString st;
				st.Format("%d", pe32.th32ProcessID);
				m_prslist.InsertItem(cnt, pe32.szExeFile, 0);
				m_prslist.SetItemText(cnt, 1, st);
				cnt++;
			}
		}

		/*_tprintf(TEXT("\n  Process ID        = 0x%08X"), pe32.th32ProcessID);
		_tprintf(TEXT("\n  Thread count      = %d"), pe32.cntThreads);
		_tprintf(TEXT("\n  Parent process ID = 0x%08X"), pe32.th32ParentProcessID);
		_tprintf(TEXT("\n  Priority base     = %d"), pe32.pcPriClassBase);
		if (dwPriorityClass)
			_tprintf(TEXT("\n  Priority class    = %d"), dwPriorityClass);*/

	} while (Process32Next(hProcessSnap, &pe32));

	CloseHandle(hProcessSnap);
	return(TRUE);
}


/////////////////////////////////////////////////////////////////////////////
// CProcessSpyDlg message handlers

BOOL CProcessSpyDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	m_prslist.InsertColumn(0, "Process Name",0, 200);
	m_prslist.InsertColumn(1, "Process ID",0,100);

	// Add "About..." menu item to system menu.
	m_prslist.SetExtendedStyle(m_prslist.GetExtendedStyle()|LVS_EX_FULLROWSELECT);

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	GetProcessList();
	DWORD dwThreadId;
	CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)RecvThread, this, 0,&dwThreadId);
	// TODO: Add extra initialization here
	return TRUE;  // return TRUE  unless you set the focus to a control
}
BOOL CProcessSpyDlg::hasHwnd(int pid) {
	HWND hCurWnd = nullptr;
	do
	{
		hCurWnd = ::FindWindowEx(nullptr, hCurWnd, nullptr, nullptr);
		DWORD checkProcessID = 0;
		::GetWindowThreadProcessId(hCurWnd, &checkProcessID);
		if (checkProcessID == pid || pid == 0)
		{
			return TRUE;
			//wprintf(L"Found hWnd %d\n", hCurWnd);
		}
	} while (hCurWnd != nullptr);
	return FALSE;
}
void CProcessSpyDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CProcessSpyDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CProcessSpyDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}
DWORD CProcessSpyDlg::RecvThread(VOID *param)
{
	CProcessSpyDlg *pDlg = (CProcessSpyDlg*)param;
	if(pDlg == NULL)
		return 0;
	return pDlg->recvFunc();
}
void CProcessSpyDlg::getProcessNamePid(char *prostr) {
	int i = 0;
	char newprocessname[512] = {0};
	char linebrk[] = "<br>";
	for(i = 0; i < g_pids.size(); i++) {
		process_inform a= g_pids.at(i);
		sprintf(newprocessname,"name:%s,  pid:%d",a.processname, a.pid);
		strcat(prostr, newprocessname);
		strcat(prostr, linebrk);
		
	}
}
int CProcessSpyDlg::getPidFromName(char *processname)
{
	int i = 0;
	char newprocessname[512] = {0};
	processname = strlwr(processname);
	for(i = 0; i < g_pids.size(); i++) {
		process_inform a= g_pids.at(i);
		memset(newprocessname, 0, 512);
		strcpy(newprocessname,strlwr(a.processname));
		
		if(strncmp(newprocessname, processname, strlen(processname)) == 0) {
			return a.pid;
		}

	}
	return 0;
}
void CProcessSpyDlg::getChildWnds(CString *fp, void *p) {
	HWND hCurWnd = nullptr;
	CString str;
	char class_name[80] = { 0 };
	hwnd_inform *pinf = (hwnd_inform*)p;
	HWND parWnd = pinf->hWnd;
	GetClassName(pinf->hWnd, class_name, sizeof(class_name));
	*fp+=("<process name=\"");
	*fp+= pinf->processname;
	str.Format("\" handle=\"%.8x\" className=\"%s\">\n", pinf->hWnd,class_name);
	*fp += str;

	displayControl(fp, pinf->hWnd, 1);

	*fp += "</process>\n";
}
void CProcessSpyDlg::makeReply(int pid, char*ret) {
	int i;
	CString s=L"<?xml version=\"1.0\" encoding=\"utf-8\"?>\n";
	vector<hwnd_inform> hwnds;
	GetAllWindowsFromProcessID(pid, hwnds);
	for (i = 0; i < hwnds.size(); i++) {
		hwnd_inform hWnd = hwnds.at(i);
		getChildWnds(&s, &hWnd);
	}
	strcat(ret, s.GetBuffer(0));
}
DWORD CProcessSpyDlg::recvFunc()
{
	int addr_len;
    struct sockaddr_in local, client_addr;

    SOCKET sock, msg_sock;
    WSADATA wsaData;

    if (WSAStartup(MAKEWORD(2, 2), &wsaData) == SOCKET_ERROR)
        error_die("WSAStartup()");

    // Fill in the address structure
    local.sin_family        = AF_INET;
    local.sin_addr.s_addr   = INADDR_ANY;
    local.sin_port          = htons(DEFAULT_PORT);

    sock = socket(AF_INET, SOCK_STREAM, 0);

    if (sock == INVALID_SOCKET)
        error_die("socket()");

    if (bind(sock, (struct sockaddr *)&local, sizeof(local)) == SOCKET_ERROR)
        error_die("bind()");
	
	char curprocesses[0x10000];
	char buff[100] = {0};
	char opt1[] = "/api/token&getprocesses";
	char opt2[] = "/api/token&processname=";
	char opt3[] = "/api/token&processid=";
	int npid;
	int sent;
listen_goto:

    if (listen(sock, 10) == SOCKET_ERROR)
        error_die("listen()");

    printf("Waiting for connection...\n");

    int count = 0;
	
    forever
    {
		memset(curprocesses, 0, 0x10000);
		

        addr_len = sizeof(client_addr);
        msg_sock = accept(sock, (struct sockaddr*)&client_addr, &addr_len);

        if (msg_sock == INVALID_SOCKET || msg_sock == -1)
            error_die("accept()");

        
        REQUEST *request = GetRequest(msg_sock);
        if (request->length == 0)
            continue;
		if(strncmp(request->value, opt1, strlen(opt1))== 0)
		{
			///sent = SendResponse(msg_sock, response);
			getProcessNamePid(curprocesses);
			sent = SendResponse(msg_sock, curprocesses);
		}
		else if(strncmp(request->value, opt2, strlen(opt2))== 0)
		{
			strcat(curprocesses, "<pre lang='xml'>");
			memset(buff, 0, 100);
			strcpy(buff, (request->value) + strlen(opt2));
			npid = getPidFromName(buff);
			makeReply(npid, curprocesses);
			strcat(curprocesses, "</pre>");
			sent = SendResponse(msg_sock, curprocesses);
		}
		else if(strncmp(request->value, opt3, strlen(opt3))== 0) {
			strcat(curprocesses, "<pre lang='xml'>");
			memset(buff, 0, 100);
			strcpy(buff, (request->value) + strlen(opt3));
			npid = atoi(buff);
			makeReply(npid, curprocesses);
			strcat(curprocesses, "</pre>");
			sent = SendResponse(msg_sock, curprocesses);
		}

        
        closesocket(msg_sock);

        //if (sent == 0)
        //    break;
        //else if (sent == -1)
            goto listen_goto;

    }

    WSACleanup();
	return 0;

	
		/*memset(buff, 0, 512);
		memset(curprocesses, 0, 0x10000);
		strcat(curprocesses, "Hello Client , That program is not running here. Process lists are:\n");
		stats = recv(new_socket, buff, 512, 0);
		if(strcmp(buff, "q") == 0)
			break;
		if(stats <=0) {
			goto WAIT;
		}
		if(strlen(buff) == 0)
		{
			Sleep(10);
			continue;
		}
		npid = getPidFromName(buff,curprocesses);
		if(npid == 0) {
			send(new_socket , curprocesses , strlen(curprocesses) , 0);
		}
		else {
			memset(curprocesses, 0, 0x10000);
			makeReply(npid, curprocesses);
			send(new_socket , curprocesses , strlen(curprocesses) , 0);
		}
		Sleep(10);*/
}
void CProcessSpyDlg::OnBtnGet() 
{
	// TODO: Add your control notification handler code here
	POSITION pos = m_prslist.GetFirstSelectedItemPosition();
	int selected = -1;
	if (pos != NULL)
	{
		while (pos)
		{
			int nItem = m_prslist.GetNextSelectedItem(pos);
			selected = nItem;
		}
	}
	if (selected == -1) {
		MessageBox("Please select process name", "Warning", MB_OK | MB_ICONWARNING);
		return;
	}
	
	strpid = m_prslist.GetItemText(selected, 1);
	GenerateXML(atoi(strpid));
}
BOOL is_main_window(HWND handle)
{
	return GetWindow(handle, GW_OWNER) == (HWND)0;
}
char *getProcessName(int pid) {
	int i;
	for (i = 0; i < g_pids.size(); i++) {
		if (g_pids.at(i).pid == pid) {
			return g_pids.at(i).processname;
		}
	}
	return NULL;
}
void CProcessSpyDlg::GetAllWindowsFromProcessID(DWORD dwProcessID, vector<hwnd_inform> &ret)
{
	// find all hWnds (vhWnds) associated with a process id (dwProcessID)
	HWND hCurWnd = nullptr;
	do
	{
		hCurWnd = ::FindWindowEx(nullptr, hCurWnd, nullptr, nullptr);
		DWORD checkProcessID = 0;
		::GetWindowThreadProcessId(hCurWnd, &checkProcessID);
		hwnd_inform inf;
		if (checkProcessID == dwProcessID || dwProcessID == 0)
		{
			if (is_main_window(hCurWnd)) {
				inf.hWnd = hCurWnd;
				char *p = getProcessName(checkProcessID);
				strcpy(inf.processname,p);
				ret.push_back(inf);
			}
										//wprintf(L"Found hWnd %d\n", hCurWnd);
		}
	} while (hCurWnd != nullptr);
}
void CProcessSpyDlg::displayControl(CString *fp, HWND hWnd, int dep) {
	HWND hCurWnd = nullptr;
	CString str;
	hCurWnd = ::FindWindowEx(hWnd, hCurWnd, nullptr, nullptr);
	int i;
	char class_name[80] = { 0 };
	char title[80] = { 0 };
	int header = 0;
	if (hCurWnd != nullptr) {
		for (i = 0; i < dep; i++)
			*fp+="\t";
		*fp+="<childrens>\n";
		header = 1;
	}
	while(hCurWnd != nullptr)
	{
		::GetClassName(hCurWnd, class_name, sizeof(class_name));
		::SendMessage(hCurWnd, WM_GETTEXT, 80, (LPARAM)title);
		for (i = 0; i <= dep; i++)
			*fp+="\t";
		str.Format("<controls type=\"window\" handle=\"%.8x\" title=\"%s\" className=\"%s\">\n", hCurWnd, title, class_name);
		*fp+=str;
		displayControl(fp, hCurWnd, dep+2);

		hCurWnd = ::FindWindowEx(hWnd, hCurWnd, nullptr, nullptr);
	}
	if (header == 1) {
		for (i = 0; i < dep; i++)
			*fp+="\t";
		*fp+="</childrens>\n";
	}
}
void CProcessSpyDlg::displayControl(FILE *fp, HWND hWnd, int dep) {
	HWND hCurWnd = nullptr;
	hCurWnd = ::FindWindowEx(hWnd, hCurWnd, nullptr, nullptr);
	int i;
	char class_name[80] = { 0 };
	char title[80] = { 0 };
	int header = 0;
	if (hCurWnd != nullptr) {
		for (i = 0; i < dep; i++)
			fprintf(fp, "\t");
		fprintf(fp, "<childrens>\n");
		header = 1;
	}
	while(hCurWnd != nullptr)
	{
		::GetClassNameA(hCurWnd, class_name, sizeof(class_name));
		::SendMessageA(hCurWnd, WM_GETTEXT, 80, (LPARAM)title);
		for (i = 0; i <= dep; i++)
			fprintf(fp, "\t");
		fprintf(fp, "<controls type=\"window\" handle=\"%.8x\" title=\"%s\" className=\"%s\">\n", hCurWnd, title, class_name);
		displayControl(fp, hCurWnd, dep+2);

		hCurWnd = ::FindWindowEx(hWnd, hCurWnd, nullptr, nullptr);
	}
	if (header == 1) {
		for (i = 0; i < dep; i++)
			fprintf(fp, "\t");
		fprintf(fp, "</childrens>\n");
	}
}
void CProcessSpyDlg::getChildWnds(FILE*fp, void *p) {
	char class_name[80] = { 0 };
	hwnd_inform *pinf = (hwnd_inform*)p;
	HWND parWnd = pinf->hWnd;
	GetClassNameA(pinf->hWnd, class_name, sizeof(class_name));

	fprintf(fp, "<process name=\"");
	fprintf(fp, pinf->processname);
	fprintf(fp, "\" handle=\"%.8x\" className=\"%s\">\n", pinf->hWnd,class_name);

	displayControl(fp, pinf->hWnd, 1);

	fprintf(fp, "</process>\n");
}
void CProcessSpyDlg::GenerateXML(int pid)
{
	int i;
	vector<hwnd_inform> hwnds;
	FILE *fp = fopen("res.xml", "w+t");
	fprintf(fp, "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n");
	if (pid == 0) {
		for (i = 0; i < g_pids.size(); i++) {
			GetAllWindowsFromProcessID(g_pids.at(i).pid, hwnds);
		}
	}
	else {
		GetAllWindowsFromProcessID(pid, hwnds);
	}
			
	for (i = 0; i < hwnds.size(); i++) {
		hwnd_inform hWnd = hwnds.at(i);
		getChildWnds(fp, &hWnd);
	}
	fclose(fp);
	MessageBox("res.xml generated. please check.", "Information", MB_OK);
}
