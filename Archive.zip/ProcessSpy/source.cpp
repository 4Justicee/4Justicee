#include "stdafx.h"
#include <winsock2.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "server.h"
#include "direct.h"
enum { RQ_UNDEF,GET,POST,PUT } response_types;

#pragma comment (lib, "ws2_32.lib")
const char *DEFAULT_ERROR_404 = "HTTP/1.1 404 Not Found\r\nContent-Type: text/html\r\n\r\n<!DOCTYPE html><html><head><title>404 Not Found</title></head><body><h1>Not Found</h1>The requested URL was not found on this server.</body></html>";
#define INVALID_FILE_ATTRIBUTES ((DWORD)-1)

BOOL FileExists(LPCTSTR szPath)
{
  DWORD dwAttrib = GetFileAttributes(szPath);

  return (dwAttrib != INVALID_FILE_ATTRIBUTES && !(dwAttrib & FILE_ATTRIBUTE_DIRECTORY));
}

char *get_content_type(char *name)
{
    char *extension = strchr(name, '.');

    if (!strcmp(extension, ".html"))
        return "text/html";
    else if (!strcmp(extension, ".ico"))
        return "image/webp";
    else if (!strcmp(extension, ".css"))
        return "text/css";
    else if (!strcmp(extension, ".jpg"))
        return "image/jpeg";
    else if (!strcmp(extension, ".js"))
        return "text/javascript";

    return "*/*";
}

char *get_header(RESPONSE *rs)
{
    if (!FileExists(TEXT(rs->filepath))) {
        printf("404 Not Found: %s\n", rs->filename);
        rs->error = 404;
        return "HTTP/1.1 404 Not Found\r\nContent-Length: 0\r\n\r\n";
    }

    char header[1024] = {0};
    sprintf(header, "HTTP/1.1 200 OK\r\nContent-Type: %s; charset=UTF-8\r\n\r\n", get_content_type(rs->filename));
    return strdup(header);
}

char *get_full_path(char *name)
{
    char filename[1024] = {0};
    _getcwd(filename, 1024);

    if ((filename[strlen(filename)] != '\\') && 
        (name[strlen(name)] != '/') &&
        (name[strlen(name)] != '\\'))
    {
        strcat(filename, "\\");
    }

    int i;
    for (i = 0; name[i]; i++)
        if (name[i] == '/')
            name[i] = '\\';

    strcat(filename, name);
    return strdup(filename);
}

RESPONSE *GetResponse(REQUEST *request)
{
    RESPONSE *response;

    response = (RESPONSE*)malloc(sizeof(RESPONSE));
    response->error    = 0;
    response->filename = request->value;
    response->filepath = get_full_path(request->value);
    response->header   = get_header(response);

    return response;
}

int SendResponse(SOCKET sock, RESPONSE *response)
{
    if (response->error) {
        send(sock, DEFAULT_ERROR_404, strlen(DEFAULT_ERROR_404), 0);
        return 1;
    }

    FILE *f = fopen(response->filepath, "rb");
    char buf[1024] = {0};
    int msg_len;

    if (!f) {
        send(sock, "HTTP/1.1 500 Internal Server Error\r\nContent-Length: 0\r\n\r\n", 57, 0);
        return 1;
    }

    send(sock, response->header, strlen(response->header), 0);

    int result = 0;
    while ((result = fread(buf, 1, 1024, f)) > 0)
    {
        msg_len = send(sock, buf, result, 0);

        if (msg_len == SOCKET_ERROR) {
            //error_live("send()");
            printf("Error sending data, reconnecting...\n");
            closesocket(sock);
            return -1;
        }
        else if (!msg_len)
        {
            printf("Client closed connection\n");
            closesocket(sock);
            return 0;
            //WSACleanup();
        }
    }

    printf("Served file %s\n", response->filepath);

    return 1;
}

int SendResponse(SOCKET sock, char *response)
{
	
	char head[] = "HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=UTF-8\r\n\r\n";
    send(sock, head, strlen(head), 0);
	char buff[1024] = {0};
    int result = 0;
	int i,n = strlen(response),ncp;
	int nc = n % 1024 == 0? n / 1024:n/1024 + 1;
	for(i = 0;i < nc; i++) 
    {
		memset(buff, 0, 1024);
		ncp = (n - i * 1024) > 1024 ? 1024 : n - i * 1024;
		memcpy(buff, response + i * 1024,ncp);
		
        ncp = send(sock, buff, ncp, 0);

        if (ncp == SOCKET_ERROR) {
            //error_live("send()");
            printf("Error sending data, reconnecting...\n");
            closesocket(sock);
            return -1;
        }
        else if (!ncp)
        {
            printf("Client closed connection\n");
            closesocket(sock);
            return 0;
            //WSACleanup();
        }
    }


    return 1;
}

int get_request_type(char *buf)
{
    char retval[10] = {0};
    sscanf(buf, "%s ", &retval);

    if (!strcmp(retval, "GET"))
        return GET;
    else if (!strcmp(retval, "POST"))
        return POST;
    else if (!strcmp(retval, "PUT"))
        return PUT;
    else
        return RQ_UNDEF;
}

char *get_request_value(char *buf)
{
    char retval[100] = {0};

    sscanf(buf, "%s %s ", &retval, &retval);  // tee hee

    if (retval[strlen(retval)-1] == '/')
        strcat(retval, "index.html");

    return strdup(retval);
}

REQUEST *GetRequest(SOCKET sock)
{
    REQUEST *request;
    int msg_len;
    char buf[REQUEST_SIZE];

    msg_len = recv(sock, buf, sizeof(buf), 0);
    //printf("Bytes Received: %d, message: %s from %s\n", msg_len, buf, inet_ntoa(client.sin_addr));

    request         = (REQUEST*)malloc(sizeof(REQUEST));
    request->type   = get_request_type(buf);
    request->value  = get_request_value(buf);
    request->length = msg_len;

    return request;
}
void error_live(const char *s)
{
    fprintf(stderr, "Error: %s failed with error %d\n", s, WSAGetLastError());
    WSACleanup();
}

void error_die(const char *s)
{
    error_live(s);
    exit(EXIT_FAILURE);
}