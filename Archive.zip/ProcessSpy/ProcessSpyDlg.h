// ProcessSpyDlg.h : header file
//

#if !defined(AFX_PROCESSSPYDLG_H__B79DDB98_8EB8_41B5_AEEF_149EFB7BAB28__INCLUDED_)
#define AFX_PROCESSSPYDLG_H__B79DDB98_8EB8_41B5_AEEF_149EFB7BAB28__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include <vector>
using namespace std;

/////////////////////////////////////////////////////////////////////////////
// CProcessSpyDlg dialog
struct process_inform {
	char processname[200];
	int pid;
};
struct hwnd_inform {
	char processname[200];
	HWND hWnd;
};
class CProcessSpyDlg : public CDialog
{
// Construction
	BOOL GetProcessList();
	void GenerateXML(int pid);
	void getChildWnds(FILE*fp, void *p);
	void getChildWnds(CString *fp, void *p);
	BOOL hasHwnd(int pid);

	static DWORD RecvThread(VOID *param);
	DWORD recvFunc();
	void makeReply(int pid, char*ret);
	int getPidFromName(char *processname);
	void GetAllWindowsFromProcessID(DWORD dwProcessID, vector<hwnd_inform> &ret);

	void displayControl(CString *fp, HWND hWnd, int dep);
	void displayControl(FILE *fp, HWND hWnd, int dep);
	void getProcessNamePid(char *prostr);
public:
	CProcessSpyDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CProcessSpyDlg)
	enum { IDD = IDD_PROCESSSPY_DIALOG };
	CListCtrl	m_prslist;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CProcessSpyDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CProcessSpyDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnBtnGet();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PROCESSSPYDLG_H__B79DDB98_8EB8_41B5_AEEF_149EFB7BAB28__INCLUDED_)
