//******************************************************************************
//
// This file is part of the OpenHoldem project
//    Source code:           https://github.com/OpenHoldem/openholdembot/
//    Forums:                http://www.maxinmontreal.com/forums/index.php
//    Licensed under GPL v3: http://www.gnu.org/licenses/gpl.html
//
//******************************************************************************
//
// Purpose: Very simple user-DLL as a starting-point
//
// Required OpenHoldem version: 12.1.6
//
//******************************************************************************

// Needs to be defined here, before #include "user.h"
// to generate proper export- and inport-definitions
#define USER_DLL

#include "user.h"
#include <conio.h>
#include <windows.h>
#include "stdio.h"
#include "OpenHoldemFunctions.h"
#include "tlhelp32.h"
#include "vector"
using namespace std;
//******************************************************************************
//
// Place all your initalizations in the functions below
// DLLOnLoad() amd DLLOnUnLoad() get called by the DLL,
// the other functions get called by OpenHoldem
//
//******************************************************************************

void DLLOnLoad() {
}

void DLLOnUnLoad() {
}

void __stdcall DLLUpdateOnNewFormula() {
}

void __stdcall DLLUpdateOnConnection() {
}

void __stdcall DLLUpdateOnHandreset() {
}

void __stdcall DLLUpdateOnNewRound() {
}

void __stdcall DLLUpdateOnMyTurn() {
}

void __stdcall DLLUpdateOnHeartbeat() {
}

char *names6[] = { "BB","UTG","MP","CO","BTN","SB" };
char *names2[] = { "BB","SB" };
char *names9[] = { "BB","UTG","UTG1","MP","MP2","HJ","CO","BTN","SB" };
char *names10[] = { "BB","UTG","UTG1","UTG2","MP","MP2","HJ","CO","BTN","SB" };
char ccs[] = "0123456789TJQKA";
char autoplayerfilename1[1024] = { 0 };
char autoplayerfilename2[1024] = { 0 };
char prevhandnum[10] = { 0 };
int tableNumber;
int openraise = 0;
char suit[] = "hdcs";	//Heart, Diamond, Club, Spade
//******************************************************************************
//
// ProcessQuery()
// Handling the lookup of dll$symbols
//
//******************************************************************************
char* GetPositionName(int bb, int npos, int nchairs) {
	int np = GetSymbol("nplayersactive");
	if (np == 2) {
		if (npos == bb)
			return names2[0];
		return names2[1];
	}
	int sb = GetSymbol("smallblindchair");
	if (npos == sb)
		return names6[5];
	sb = GetSymbol("dealerchair");
	if (sb == npos)
		return names6[4];
	sb = GetSymbol("cutoffchair");
	if (sb == npos)
		return names6[3];
	sb = GetSymbol("utgchair");
	if (sb == npos)
		return names6[1];
	sb = GetSymbol("mp3chair");
	if (sb == npos)
		return names6[2];
	return names6[0];
}
int getDistance(int bb, int npos, int nchair) {
	if (npos == bb)
		return nchair;
	int noffset = (npos > bb) ? npos-bb : npos + nchair - bb;
	return noffset;
}
int getOpenRaise(char *buff) {
	int bet1 = GetSymbol("bet1");
	int round = GetSymbol("betround");
	if (round == 2) {
		itoa(bet1, buff, 10);
		return 0;
	}
	int sb = GetSymbol("smallblindchair");
	int de = GetSymbol("dealerchair");
	int bb = GetSymbol("bigblindchair");
	int utg = GetSymbol("utgchair");
	int mp3 = GetSymbol("mp3chair");
	int co = GetSymbol("cutoffchair");
	int arr[6], starti;
	int i,b2=0,b;
	char buff2[20];
	b = GetSymbol("bblind");
	arr[0] = sb; arr[1] = bb; arr[2] = utg; arr[3] = mp3; arr[4] = co; arr[5] = de;
	for (i =2; i < 8; i++) {
		int ne = (i >= 5) ? i % 6 : i;
		ne = arr[ne];
		sprintf(buff2, "currentbet%d", ne);
		b2 = GetSymbol(buff2);
		if (b2 > b && openraise == 0) {
			openraise = b2;
			break;
		}
	}
	if(openraise != 0)
		itoa(openraise, buff, 10);
	return 0;
}
void getMyCardString(char *mycard) {
	int c1 = GetSymbol("$$pr0");	//Get My card0
	int c2 = GetSymbol("$$pr1");	//Get my card1
	int s1 = GetSymbol("$$ps0");	//get my card suit0
	int s2 = GetSymbol("$$ps1");	//get my card suit1
	mycard[0] = ccs[c1];
	mycard[1] = suit[s1];
	mycard[2] = ccs[c2];
	mycard[3] = suit[s2];	//Return value looks like AsTc
}
void getBoardCardFlop(char *cboard) {
	int c1 = GetSymbol("$$cr0");	//Get My card0
	int c2 = GetSymbol("$$cr1");	//Get my card1
	int c3 = GetSymbol("$$cr2");	//Get my card1
	int s1 = GetSymbol("$$cs0");	//get my card suit0
	int s2 = GetSymbol("$$cs1");	//get my card suit1
	int s3 = GetSymbol("$$cs2");
	cboard[0] = ccs[c1];
	cboard[1] = suit[s1];
	cboard[2] = ccs[c2];
	cboard[3] = suit[s2];
	cboard[4] = ccs[c3];
	cboard[5] = suit[s3];	//Return value looks like AsTc
}
void getBoardCardTurn(char *cboard) {
	int c1 = GetSymbol("$$cr3");	//Get My card0
	int s1 = GetSymbol("$$cs3");	//get my card suit0
	cboard[0] = ccs[c1];
	cboard[1] = suit[s1];	//Return value looks like AsTc
}
void getBoardCardRiver(char *cboard) {
	int c1 = GetSymbol("$$cr4");	//Get My card0
	int s1 = GetSymbol("$$cs4");	//get my card suit0
	cboard[0] = ccs[c1];
	cboard[1] = suit[s1];	//Return value looks like AsTc
}
int FindRunningProcess(char* process) {
	/*
	Function takes in a string value for the process it is looking for like ST3Monitor.exe
	then loops through all of the processes that are currently running on windows.
	If the process is found it is running, therefore the function returns true.
	*/
	char *compare;
	bool procRunning = false;

	HANDLE hProcessSnap;
	PROCESSENTRY32 pe32;
	hProcessSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
	int nid = 0;
	if (hProcessSnap == INVALID_HANDLE_VALUE) {
		procRunning = false;
	}
	else {
		pe32.dwSize = sizeof(PROCESSENTRY32);
		if (Process32First(hProcessSnap, &pe32)) { // Gets first running process
			if (pe32.szExeFile == process) {
				procRunning = true;
			}
			else {
				// loop through all running processes looking for process
				while (Process32Next(hProcessSnap, &pe32)) {
					// Set to an AnsiString instead of Char[] to make compare easier
					compare = pe32.szExeFile;
					if (compare == process) {
						// if found process is running, set to true and break from loop
						nid++;
					}
				}
			}
			// clean the snapshot object
			CloseHandle(hProcessSnap);
		}
	}

	return nid;
}
void getEffectiveStack(char *stacks) {
	int me = GetSymbol("userchair");
	int bblind = GetSymbol("bblind");
	int smallest_stack = 999999999;
	int activeflag = GetSymbol("playersplayingbits");
	char temp[10] = { 0 };
	int i;
	for (i = 0; i < 10; i++) {
		if (activeflag &(1 << i)) {
			//This player is playing
			sprintf(temp, "balance%d", i);
			int bala = GetSymbol(temp);
			if (smallest_stack > bala)
				smallest_stack = bala;
		}
	}
	itoa(smallest_stack, stacks, 10);
}

void makeHistoryObject(char *st, char *handnum) {	//Automatic Actions
	//bflop 0 means : Before Flop
	//bflop 1 means : After Flop

	int i;
	char buff[1024] = { 0 };
	char buff1[20], buff2[20];
	if (strlen(prevhandnum) == 0) {
		strcpy(prevhandnum, handnum);
	}
	else {
		if (strncmp(prevhandnum, handnum, strlen(handnum))) {
			memset(autoplayerfilename1, 0, 1024);
			memset(autoplayerfilename2, 0, 1024);
			memset(prevhandnum, 0, 10);
			strcpy(prevhandnum, handnum);
		}
	}
	if (strlen(autoplayerfilename1) == 0) {
		if (strcmp(st, "BF") == 0) {
			sprintf(autoplayerfilename1, "[-%d-]_FFLOW@BF", tableNumber);
		}
	}
	if (strlen(autoplayerfilename2) == 0)
	{
		if (strcmp(st, "AF") == 0) {
			sprintf(autoplayerfilename2, "[-%d-]_FFLOW@AF", tableNumber);
		}
	}

	
	if (strcmp(st,"BF") == 0) {
		int myposition = GetSymbol("userchair");	// This is my position
		int sb = GetSymbol("smallblindchair");
		int de = GetSymbol("dealerchair");
		int bb = GetSymbol("bigblindchair");
		int utg = GetSymbol("utgchair");
		int mp3 = GetSymbol("mp3chair");
		int co = GetSymbol("cutoffchair");
		int arr[6], starti,b1, b2;
		
		memset(buff, 0, 1024);
		strcpy(buff, autoplayerfilename1);
		strcat(buff, "-");
		strcat(buff, handnum);
		DeleteFile(buff);
		memset(buff, 0, 1024);

		arr[0] = sb; arr[1] = bb; arr[2] = utg; arr[3] = mp3; arr[4] = co; arr[5] = de;
		sprintf(buff1, "currentbet%d", sb);
		sprintf(buff2, "currentbet%d", bb);
		int sblind = GetSymbol(buff1);
		int bblind = GetSymbol(buff2);
		int fc = 0;

		for (i = 0; i < 6; i++) {
			if (arr[i] == myposition) {
				starti = i;
				fc = GetSymbol("currentbet");
				break;
			}
		}
		bool notnull = 0;
		
		while (1) {
			i = starti + 1;
			int ne = (i > 5) ? i % 6 : i;
			ne = arr[ne];
		
			
			if (ne == sb)
				break;
			sprintf(buff2, "currentbet%d", ne);
			b2 = GetSymbol(buff2);
			if (b2) {
				notnull = 1;
				break;
			}
			starti++;
		}
		if (sblind == 5 && bblind == 10 && notnull == 0) {
			starti = 1;
			fc = bblind;
		}
		else {
			for (i = 0; i < 6; i++) {
				if (arr[i] == myposition) {
					starti = i;
					break;
				}
			}
			int ne, nt;
			while (1) {
				i = starti-1;
				if (i >= 0) ne = i;
				else {
					nt = abs(i) % 6 == 0 ? abs(i) / 6 : abs(i) / 6 + 1;
					ne = nt * 6 - abs(i);
				}
				ne = arr[ne];
				
				b2 = GetSymbol(buff2);
				if (b2) {
					starti = i;
					fc = b2;
					break;
				}
				starti--;
			}
		}
		for (i = starti+1; i < starti + 6; i++) {
			int ne = (i >= 5) ? i % 6 : i;
			ne = arr[ne];
			sprintf(buff2, "currentbet%d", ne);
			
			b2 = GetSymbol(buff2);
			memset(buff, 0, 1024);
			if (b2 > fc) {
				sprintf(buff, "@b%d", b2);
				fc = b2;
			}
			else if (b2 == fc) {
				sprintf(buff, "@c");
			}
			else
				continue;
			strcat(autoplayerfilename1, buff);
		}
		
		memset(buff, 0, 1024);
		strcpy(buff, autoplayerfilename1);

		strcat(buff, "-");
		strcat(buff, handnum);
		FILE *fp = fopen(buff,"wb");
		fclose(fp);
	}
	else {
		memset(buff, 0, 1024);
		strcpy(buff, autoplayerfilename2);
		strcat(buff, "-");
		strcat(buff, handnum);
		DeleteFile(buff);

		if (strcmp(st, "T") == 0) {
			char *pt = strstr(autoplayerfilename2, "@T");
			if(pt == NULL)
				strcat(autoplayerfilename2, "@T");
		}
		if (strcmp(st, "R") == 0) {
			char *pr = strstr(autoplayerfilename2, "@R");
			if (pr == NULL)
				strcat(autoplayerfilename2, "@R");
		}
		memset(buff, 0, 1024);
		int headupchar = GetSymbol("headsupchair");
		int myposition = GetSymbol("userchair");
		sprintf(buff1, "currentbet%d", headupchar);
		sprintf(buff2, "currentbet%d", myposition);
		int b1 = GetSymbol(buff1);
		int b2 = GetSymbol(buff2);
		if (b1 == b2) {
			//This is check or call
			sprintf(buff, "@c");
		}
		if (b1 > b2) {
			//this is raise
			sprintf(buff, "@b%d", b1 - b2);
		}
		if (b2 > b1) {
			sprintf(buff, "@b%d", b2 - b1);
		}

		strcat(autoplayerfilename2, buff);
		memset(buff, 0, 1024);
		strcpy(buff, autoplayerfilename2);
		strcat(buff, "-");
		strcat(buff, handnum);
		FILE *fp = fopen(buff, "wb");
		fclose(fp);
	}
}
int findVillarin() {
	int sb = GetSymbol("smallblindchair");
	int de = GetSymbol("dealerchair");
	int bb = GetSymbol("bigblindchair");
	int utg = GetSymbol("utgchair");
	int mp3 = GetSymbol("mp3chair");
	int co = GetSymbol("cutoffchair");
	char buff[10] = { 0 };
	int arr[10] = { 0 };
	int i,t,amount, maxv = 0, largei = 0;
	arr[0] = sb; arr[1] = bb; arr[2] = utg; arr[3] = mp3; arr[4] = co; arr[5] = de;
	for (i = 0; i < 6; i++) {
		t = arr[i];
		sprintf(buff, "currentbet%d", t);
		amount = GetSymbol(buff);
		if (amount > maxv) {
			maxv = amount;
			largei = t;
		}
	}
	return largei;//Largest betting is villarin
}
void FindPFfileandGen(char *handnums) {
	char saveline[1000] = { 0 };
	char mycards[5] = { 0 };
	int nchairs = GetSymbol("nplayersactive");			//GetSymbol("nplayersseated");
	char raiseval[10] = { 0 };
	int myposition = GetSymbol("userchair");	// This is my position
	int sb = GetSymbol("smallblindchair");	// This is small blind position
	int bb = GetSymbol("bigblindchair");		//BigBlindposition
	int headupchar = GetSymbol("headsupchair");	//This is my oppent, villarin's chair
	int nf = GetSymbol("firstraiserchair");
	int dist1, dist2;
	DWORD dw;
	
	if (headupchar == -1) headupchar = findVillarin();
	
	char strfilename[MAX_PATH];		//File Name, I can not understand what is table number.
	sprintf(strfilename, "[-%d-]_PF-", tableNumber);
	strcat(strfilename, handnums);					//So I made it default 3

	WIN32_FIND_DATA fd;
	if (FindFirstFile(strfilename, &fd) != INVALID_HANDLE_VALUE)
		return;
	HANDLE hFile = CreateFile(strfilename,                // name of the write
		GENERIC_WRITE,          // open for writing
		0,                      // do not share
		NULL,                   // default security
		CREATE_NEW,             // create new file only
		FILE_ATTRIBUTE_NORMAL,  // normal file
		NULL);                  // no attr. template
	if (hFile == INVALID_HANDLE_VALUE)
	{
		return;
	}

	if (nchairs == 6) {
		//This is 6 max cash mode;
		strcat(saveline, "spot: 100bb_mon5z-");
	}
	else {
		double mybalance = GetSymbol("balance");		//my balance
		double bblind = GetSymbol("bblind");			//big blind size
		int stacksize = mybalance / bblind;			//This is my stacksize
		sprintf(saveline, "spot: %dbb-", stacksize);
	}
	if (nf == -1) {
		char *name_me = GetPositionName(bb, myposition, nchairs);
		char *name_vi = GetPositionName(bb, headupchar, nchairs);
		if (!(myposition == sb || myposition == bb)) {
			//This is we are not sb and bb, so IP
			strcat(saveline, name_me);
			strcat(saveline, "-");
			strcat(saveline, name_vi);
			strcat(saveline, "\r\n");
			strcat(saveline, "position: IP\r\n");
		}
		else {
			strcat(saveline, name_vi);
			strcat(saveline, "-");
			strcat(saveline, name_me);
			strcat(saveline, "\r\n");
			strcat(saveline, "position: OOP\r\n");
		}
	}
	else {
		if (myposition == bb) {		//I am BB
									//I am last act,
			strcat(saveline, "BB-");	//BB is last position
			char *sname = GetPositionName(bb, headupchar, nchairs);		//Make earlier positin
			strcat(saveline, sname);	//
			strcat(saveline, "\r\n");		//linebreak
			strcat(saveline, "position: IP\r\n");	//I am a last actor

		}
		else {
			dist1 = getDistance(bb, myposition, nchairs);
			dist2 = getDistance(bb, headupchar, nchairs);
			char *name_me = GetPositionName(bb, myposition, nchairs);
			char *name_vi = GetPositionName(bb, headupchar, nchairs);

			if (dist1 > dist2) {
				//I am IP, later position than villarin
				strcat(saveline, name_me);
				strcat(saveline, "-");
				strcat(saveline, name_vi);
				strcat(saveline, "\r\n");
				strcat(saveline, "position: IP\r\n");
			}
			else {
				//Sadly, I am OOP, earlier position than villarin
				strcat(saveline, name_vi);
				strcat(saveline, "-");
				strcat(saveline, name_me);
				strcat(saveline, "\r\n");
				strcat(saveline, "position: OOP\r\n");
			}
		}
	}
	getMyCardString(mycards);
	strcat(saveline, "myCards: ");
	strcat(saveline, mycards);
	strcat(saveline, "\r\n");

	getOpenRaise(raiseval);
	strcat(saveline, "openRaise: ");
	strcat(saveline, raiseval);
	strcat(saveline, "\r\n");

	WriteFile(hFile, saveline, strlen(saveline), &dw, 0);
	CloseHandle(hFile);
}

DLL_IMPLEMENTS double __stdcall ProcessQuery(const char* pquery) {
  if (pquery == NULL) {
    return 0;
  }
  if (strncmp(pquery,"dll$test",9)==0) {
	  char* question = "blahdibah";
	  double answer = 42.0;
	  WriteLog("%s %f\n", question, answer);
	  
	  HANDLE hFile;
	  char saveline[1000] = { 0 };
	  char handnums[10] = { 0 };
	  DWORD dw;
	  int round = GetSymbol("betround");
	  int nchairs = GetSymbol("nplayersactive");			//GetSymbol("nplayersseated");
	  int nactive = GetSymbol("nplayersplaying");	//Current players playing nplayersactive
	  int nfold = GetSymbol("nopponentsfolded");
	  strcpy(handnums, GetHandnumber()); //Hand number
	  char raiseval[10] = { 0 };
	  
	  if (nchairs > 6)
		  return GetSymbol("random");
	  if(round == 1)
		  makeHistoryObject("BF", handnums);
	 
	  switch (round) {
	  case 1:			//preflop
	  {
		  char mycards[5] = { 0 };		 
		  int myposition = GetSymbol("userchair");	// This is my position
		  int sb = GetSymbol("smallblindchair");	// This is small blind position
		  int bb = GetSymbol("bigblindchair");		//BigBlindposition
		  int headupchar = GetSymbol("headsupchair");	//This is my oppent, villarin's chair
		  int nf = GetSymbol("firstraiserchair");
		  int dist1, dist2;

		  if (headupchar == -1) headupchar = findVillarin();
		  char strfilename[MAX_PATH];		//File Name, I can not understand what is table number.
		  sprintf(strfilename, "[-%d-]_PF-", tableNumber);
		  strcat(strfilename, handnums);					//So I made it default 3
		  WIN32_FIND_DATA fd;
		  if (FindFirstFile(strfilename, &fd) != INVALID_HANDLE_VALUE)
		  {
			  sprintf(strfilename, "[-%d-]_PFCONT-", tableNumber);
			  strcat(strfilename, handnums);
		  }

		  hFile = CreateFile(strfilename,                // name of the write
			  GENERIC_WRITE,          // open for writing
			  0,                      // do not share
			  NULL,                   // default security
			  CREATE_ALWAYS,             // create new file only
			  FILE_ATTRIBUTE_NORMAL,  // normal file
			  NULL);                  // no attr. template
		  if (hFile == INVALID_HANDLE_VALUE)
		  {
			  return 0;
		  }

		  if (nchairs == 6) {
			  //This is 6 max cash mode;
			  strcat(saveline, "spot: 100bb_mon5z-");			  
		  }
		  else {
			  double mybalance = GetSymbol("balance");		//my balance
			  double bblind = GetSymbol("bblind");			//big blind size
			  int stacksize = mybalance / bblind;			//This is my stacksize
			  sprintf(saveline, "spot: %dbb-", stacksize);
		  }
		  if (nf == -1) {
			  char *name_me = GetPositionName(bb, myposition, nchairs);
			  char *name_vi = GetPositionName(bb, headupchar, nchairs);
			  if (!(myposition == sb || myposition == bb)) {
				  //This is we are not sb and bb, so IP
				  strcat(saveline, name_me);
				  strcat(saveline, "-");
				  strcat(saveline, name_vi);
				  strcat(saveline, "\r\n");
				  strcat(saveline, "position: IP\r\n");
			  }
			  else {
				  strcat(saveline, name_vi);
				  strcat(saveline, "-");
				  strcat(saveline, name_me);
				  strcat(saveline, "\r\n");
				  strcat(saveline, "position: OOP\r\n");
			  }
		  }
		  else {
			  if (myposition == bb) {		//I am BB
				  //I am last act,
				  strcat(saveline, "BB-");	//BB is last position
				  char *sname = GetPositionName(bb, headupchar, nchairs);		//Make earlier positin
				  strcat(saveline, sname);	//
				  strcat(saveline, "\r\n");		//linebreak
				  strcat(saveline, "position: IP\r\n");	//I am a last actor
			  }
			  else {

				  dist1 = getDistance(bb, myposition, nchairs);
				  dist2 = getDistance(bb, headupchar, nchairs);
				  char *name_me = GetPositionName(bb, myposition, nchairs);
				  char *name_vi = GetPositionName(bb, headupchar, nchairs);
				  if (dist1 > dist2) {
					  //I am IP, later position than villarin
					  strcat(saveline, name_me);
					  strcat(saveline, "-");
					  strcat(saveline, name_vi);
					  strcat(saveline, "\r\n");
					  strcat(saveline, "position: IP\r\n");
				  }
				  else {
					  //Sadly, I am OOP, earlier position than villarin
					  strcat(saveline, name_vi);
					  strcat(saveline, "-");
					  strcat(saveline, name_me);
					  strcat(saveline, "\r\n");
					  strcat(saveline, "position: OOP\r\n");
				  }
			  }
		  }
		  getMyCardString(mycards);
		  strcat(saveline, "myCards: ");
		  strcat(saveline, mycards);
		  strcat(saveline, "\r\n");

		  getOpenRaise(raiseval);
		  strcat(saveline, "openRaise: ");
		  strcat(saveline, raiseval);
		  strcat(saveline, "\r\n");

		  WriteFile(hFile, saveline, strlen(saveline), &dw, 0);
		  CloseHandle(hFile);
	  }
		  break;
	  case 2:			//flop
	  {
		  if (nactive != 2) {
			  return GetSymbol("random");//I asked to checkMath API support team, and they said they only support 1 vs 1 situation now
		  }
		  char strfilename[MAX_PATH];
		  FindPFfileandGen(handnums);
		  makeHistoryObject("AF",handnums);
		  sprintf(strfilename, "[-%d-]_BOARD-", tableNumber);
		  strcat(strfilename, handnums);
		  hFile = CreateFile(strfilename,                // name of the write
			  GENERIC_WRITE,          // open for writing
			  0,                      // do not share
			  NULL,                   // default security
			  CREATE_NEW,             // create new file only
			  FILE_ATTRIBUTE_NORMAL,  // normal file
			  NULL);                  // no attr. template
		  if (hFile == INVALID_HANDLE_VALUE)
		  {
			  return 0;
		  }
		  char flopcards[7] = { 0 };
		  char stacks[10] = { 0 };
		  getBoardCardFlop(flopcards);
		  strcat(saveline, "flopCards: ");
		  strcat(saveline, flopcards);
		  strcat(saveline, "\r\n");

		  getEffectiveStack(stacks);
		  strcat(saveline, "Stack: ");
		  strcat(saveline, stacks);
		  strcat(saveline, "\r\n");
		  WriteFile(hFile, saveline, strlen(saveline), &dw, 0);
		  CloseHandle(hFile);
	  }
		  break;
	  case 3:			//turn
	  {
		  if (nactive != 2) {
			  return GetSymbol("random");//I asked to checkMath API support team, and they said they only support 1 vs 1 situation now
		  }
		  char strfilename[MAX_PATH];
		  makeHistoryObject("T",handnums);
		  sprintf(strfilename, "[-%d-]_TURN-", tableNumber);
		  strcat(strfilename, handnums);
		  hFile = CreateFile(strfilename,                // name of the write
			  GENERIC_WRITE,          // open for writing
			  0,                      // do not share
			  NULL,                   // default security
			  CREATE_NEW,             // create new file only
			  FILE_ATTRIBUTE_NORMAL,  // normal file
			  NULL);                  // no attr. template
		  if (hFile == INVALID_HANDLE_VALUE)
		  {
			  return 0;
		  }
		  char turncard[3] = { 0 };
		  char stacks[10] = { 0 };
		  getBoardCardTurn(turncard);
		  strcat(saveline, "turnCard: ");
		  strcat(saveline, turncard);
		  strcat(saveline, "\r\n");

		  getEffectiveStack(stacks);
		  strcat(saveline, "Stack: ");
		  strcat(saveline, stacks);
		  strcat(saveline, "\r\n");
		  WriteFile(hFile, saveline, strlen(saveline), &dw, 0);
		  CloseHandle(hFile);
	  }
		  break;
	  case 4:			//river
	  {
		  if (nactive != 2) {
			  return GetSymbol("random");//I asked to checkMath API support team, and they said they only support 1 vs 1 situation now
		  }
		  char strfilename[MAX_PATH];
		  makeHistoryObject("R",handnums);

		  sprintf(strfilename, "[-%d-]_RIVER-", tableNumber);
		  strcat(strfilename, handnums);
		  hFile = CreateFile(strfilename,                // name of the write
			  GENERIC_WRITE,          // open for writing
			  0,                      // do not share
			  NULL,                   // default security
			  CREATE_NEW,             // create new file only
			  FILE_ATTRIBUTE_NORMAL,  // normal file
			  NULL);                  // no attr. template
		  if (hFile == INVALID_HANDLE_VALUE)
		  {
			  return 0;
		  }
		  char rivercard[3] = { 0 };
		  char stacks[10] = { 0 };
		  getBoardCardRiver(rivercard);
		  strcat(saveline, "riverCard: ");
		  strcat(saveline, rivercard);
		  strcat(saveline, "\r\n");

		  getEffectiveStack(stacks);
		  strcat(saveline, "Stack: ");
		  strcat(saveline, stacks);
		  strcat(saveline, "\r\n");
		  WriteFile(hFile, saveline, strlen(saveline), &dw, 0);
		  CloseHandle(hFile);
	  }
		  break;
	  }
    return GetSymbol("random");
  }
  if (strncmp(pquery, "dll$scrape", 11) == 0) {
    char* scraped_result;
    int result_lenght;
    scraped_result = ScrapeTableMapRegion("p0balance", result_lenght);
    if (scraped_result != nullptr) {
      // The TEXT() macro supports both ASCII and Unicode.
      // For the people who use Unicode but don't understand the "error".
      // http://www.maxinmontreal.com/forums/viewtopic.php?f=174&t=19999
      // http://stackoverflow.com/questions/15498070/what-does-t-stands-for-in-a-cstring
      MessageBox(0, scraped_result, TEXT("Scraped custom region"), 0);
      LocalFree(scraped_result);
    }
  }
	return 0;
}

//******************************************************************************
//
// DLL entry point
//
//******************************************************************************

BOOL APIENTRY DllMain(HANDLE hModule, DWORD ul_reason_for_call, LPVOID lpReserved) {
  switch (ul_reason_for_call)	{
		case DLL_PROCESS_ATTACH:
#ifdef _DEBUG
			AllocConsole();
#endif _DEBUG
			tableNumber = FindRunningProcess("OpenHoldem.exe");
			InitializeOpenHoldemFunctionInterface();
			break;
		case DLL_THREAD_ATTACH:
			break;
		case DLL_THREAD_DETACH:
			break;
		case DLL_PROCESS_DETACH:
#ifdef _DEBUG
			FreeConsole();
#endif _DEBUG
			break;
    }
  return TRUE;
}
